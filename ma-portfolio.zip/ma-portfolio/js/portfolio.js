// 	When the user scrolls the page, execute sticky_nabar 

// Get the navbar
var navbar = document.getElementById('nav');

// 	Get the offset position of the navbar
var sticky = navbar.offsetTop;

// 	Add the sticky class to the navbar when you reach its scroll position. Remove 'sticky' when you leave the scroll position
function sticky_nabar() {
	if (window.pageYOffset >= sticky) {
    	navbar.classList.add('sticky');
  	} else {
		navbar.classList.remove('sticky');
  	}
}

window.onscroll = function() {
	sticky_nabar();
};


//	navlink sel maken
var navlinks = document.getElementsByClassName('navlink');

var maak_selected_navlink = function() {
    var attribute = this.getAttribute('href');//niet nodig
	
	//eest eventuele selected class verwijderen
	for (var i = 0; i < navlinks.length; i++) { //loopje door alle navlink classes
		navlinks[i].classList.remove('sel'); //class verwijderen
	}
	//dan de geklikte selected maken door .sel toe te voegen
    this.classList.add('sel'); //bij geklikte navlink class toevoegen
};

// alle event listeners voor de navlinks maken
for (var i = 0; i < navlinks.length; i++) { //loopje door alle navlink classes
    navlinks[i].addEventListener('click', maak_selected_navlink, false);
}

// smooth scroll 
$(document).ready(function (){ //pagina is klaar met laden

	$('.navlink').click(function(e) {//klik op een link in de nav
		e.preventDefault();//doe niet wat je normaal doet als link
		var ga_naar_div = $(e.target).attr('href');//wat staat er in de href?, dat is dezelfde naam als de id van de div waarheen je moet scrollen
		$([document.documentElement, document.body]).animate({//animeer de hele body
			scrollTop: $(ga_naar_div).offset().top//ga naar de y-positie van een div
		}, 1500);//doe dat in 1500 miliseconden
	});

});